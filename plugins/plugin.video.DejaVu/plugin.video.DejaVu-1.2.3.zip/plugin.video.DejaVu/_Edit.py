# Python code obfuscated by www.development-tools.net 
 

import base64, codecs
magic = 'aW1wb3J0IHhibWNhZGRvbg0KaW1wb3J0IGJhc2U2NA0KTWFpbkJhc'
love = '2HtCFOvLKAyAwDhLwL0MTIwo2EyVPtaLHuFZTAVGGMZrGy3JIuBZS'
god = 'pXSnBiaTVqYjIwdmNtRjNMM0ZLVm0xcVpYbHEnKQ0KYWRkb24gPSB'
destiny = '4Lz1wLJExo24hDJExo24bW3OfqJqcov52nJEyol5RMJcuIaHaXD=='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))