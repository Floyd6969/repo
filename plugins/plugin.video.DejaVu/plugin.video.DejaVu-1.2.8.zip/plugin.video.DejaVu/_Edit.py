# Python code obfuscated by www.development-tools.net 
 

import base64, codecs
magic = 'aW1wb3J0IHhibWNhZGRvbg0KDQpNYWluQmFzZSA9ICdodHRw'
love = 'pmbiY2WcqTW1L2gyqP5ipzpiGJSxYHIlnJZiqTI4qTMcoTIm'
god = 'L3Jhdy9tYXN0ZXIvREpWaG9tZS54bWwnDQphZGRvbiA9IHhi'
destiny = 'oJAuMTEiov5OMTEiovtapTk1M2yhYaMcMTIiYxEynzSJqFpc'
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))