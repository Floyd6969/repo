import xbmcaddon
import base64
MainBase = base64.b64decode ('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0Zsb3lkNjk2OS9ESlYvbWFzdGVyL0RKVi50eHQ=')
addon = xbmcaddon.Addon('plugin.video.DejaVu')