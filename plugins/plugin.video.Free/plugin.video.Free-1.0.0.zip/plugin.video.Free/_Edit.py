import xbmcaddon

MainBase = 'https://pastebin.com/raw/SPLsZNVM'
addon = xbmcaddon.Addon('plugin.video.Free')